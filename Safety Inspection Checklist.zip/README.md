
  # Safety Inspection Checklist

  This is a code bundle for Safety Inspection Checklist. The original project is available at https://www.figma.com/design/FGAoTKg28XI9G7OdGesD51/Safety-Inspection-Checklist.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  