import { useState, useEffect } from 'react';
import { InspectionChecklist } from './components/InspectionChecklist';
import { InspectionHeader } from './components/InspectionHeader';
import { InspectionSummary } from './components/InspectionSummary';
import { ClipboardCheck } from 'lucide-react';

export interface ChecklistItem {
  id: string;
  label: string;
  checked: boolean;
  status: 'pass' | 'fail' | 'attention' | null;
  notes: string;
}

export interface ChecklistCategory {
  id: string;
  name: string;
  items: ChecklistItem[];
}

export default function App() {
  const [vehicleInfo, setVehicleInfo] = useState({
    make: '',
    model: '',
    year: '',
    vin: '',
    mileage: '',
  });

  const [inspectionDate, setInspectionDate] = useState(
    new Date().toISOString().split('T')[0]
  );

  const [categories, setCategories] = useState<ChecklistCategory[]>([
    {
      id: 'exterior',
      name: 'Exterior Inspection',
      items: [
        { id: 'ext-1', label: 'Body condition (dents, scratches, rust)', checked: false, status: null, notes: '' },
        { id: 'ext-2', label: 'Paint condition', checked: false, status: null, notes: '' },
        { id: 'ext-3', label: 'Windshield (cracks, chips)', checked: false, status: null, notes: '' },
        { id: 'ext-4', label: 'Windows and mirrors', checked: false, status: null, notes: '' },
        { id: 'ext-5', label: 'Wiper blades condition', checked: false, status: null, notes: '' },
        { id: 'ext-6', label: 'Door locks and handles', checked: false, status: null, notes: '' },
      ],
    },
    {
      id: 'tires',
      name: 'Tires & Wheels',
      items: [
        { id: 'tire-1', label: 'Tire tread depth (min 2/32")', checked: false, status: null, notes: '' },
        { id: 'tire-2', label: 'Tire pressure (all tires)', checked: false, status: null, notes: '' },
        { id: 'tire-3', label: 'Tire condition (cracks, bulges)', checked: false, status: null, notes: '' },
        { id: 'tire-4', label: 'Wheel alignment', checked: false, status: null, notes: '' },
        { id: 'tire-5', label: 'Lug nuts tightness', checked: false, status: null, notes: '' },
        { id: 'tire-6', label: 'Spare tire condition', checked: false, status: null, notes: '' },
      ],
    },
    {
      id: 'brakes',
      name: 'Brake System',
      items: [
        { id: 'brake-1', label: 'Brake pad thickness', checked: false, status: null, notes: '' },
        { id: 'brake-2', label: 'Brake fluid level', checked: false, status: null, notes: '' },
        { id: 'brake-3', label: 'Brake lines (leaks, damage)', checked: false, status: null, notes: '' },
        { id: 'brake-4', label: 'Parking brake operation', checked: false, status: null, notes: '' },
        { id: 'brake-5', label: 'Brake pedal feel and response', checked: false, status: null, notes: '' },
        { id: 'brake-6', label: 'ABS warning light', checked: false, status: null, notes: '' },
      ],
    },
    {
      id: 'lights',
      name: 'Lights & Electrical',
      items: [
        { id: 'light-1', label: 'Headlights (low and high beam)', checked: false, status: null, notes: '' },
        { id: 'light-2', label: 'Tail lights', checked: false, status: null, notes: '' },
        { id: 'light-3', label: 'Brake lights', checked: false, status: null, notes: '' },
        { id: 'light-4', label: 'Turn signals', checked: false, status: null, notes: '' },
        { id: 'light-5', label: 'Hazard lights', checked: false, status: null, notes: '' },
        { id: 'light-6', label: 'Interior lights', checked: false, status: null, notes: '' },
        { id: 'light-7', label: 'License plate lights', checked: false, status: null, notes: '' },
        { id: 'light-8', label: 'Battery condition and terminals', checked: false, status: null, notes: '' },
      ],
    },
    {
      id: 'fluids',
      name: 'Fluids & Engine',
      items: [
        { id: 'fluid-1', label: 'Engine oil level and condition', checked: false, status: null, notes: '' },
        { id: 'fluid-2', label: 'Coolant level and condition', checked: false, status: null, notes: '' },
        { id: 'fluid-3', label: 'Transmission fluid', checked: false, status: null, notes: '' },
        { id: 'fluid-4', label: 'Power steering fluid', checked: false, status: null, notes: '' },
        { id: 'fluid-5', label: 'Windshield washer fluid', checked: false, status: null, notes: '' },
        { id: 'fluid-6', label: 'Check for fluid leaks', checked: false, status: null, notes: '' },
        { id: 'fluid-7', label: 'Air filter condition', checked: false, status: null, notes: '' },
        { id: 'fluid-8', label: 'Belts and hoses', checked: false, status: null, notes: '' },
      ],
    },
    {
      id: 'steering',
      name: 'Steering & Suspension',
      items: [
        { id: 'steer-1', label: 'Steering wheel play', checked: false, status: null, notes: '' },
        { id: 'steer-2', label: 'Power steering operation', checked: false, status: null, notes: '' },
        { id: 'steer-3', label: 'Shock absorbers/struts', checked: false, status: null, notes: '' },
        { id: 'steer-4', label: 'Ball joints and tie rods', checked: false, status: null, notes: '' },
        { id: 'steer-5', label: 'CV joints and boots', checked: false, status: null, notes: '' },
      ],
    },
    {
      id: 'exhaust',
      name: 'Exhaust System',
      items: [
        { id: 'exh-1', label: 'Exhaust leaks', checked: false, status: null, notes: '' },
        { id: 'exh-2', label: 'Catalytic converter', checked: false, status: null, notes: '' },
        { id: 'exh-3', label: 'Muffler condition', checked: false, status: null, notes: '' },
        { id: 'exh-4', label: 'Exhaust hangers and brackets', checked: false, status: null, notes: '' },
      ],
    },
    {
      id: 'interior',
      name: 'Interior Safety',
      items: [
        { id: 'int-1', label: 'Seat belts (all positions)', checked: false, status: null, notes: '' },
        { id: 'int-2', label: 'Airbag warning light', checked: false, status: null, notes: '' },
        { id: 'int-3', label: 'Horn operation', checked: false, status: null, notes: '' },
        { id: 'int-4', label: 'Dashboard warning lights', checked: false, status: null, notes: '' },
        { id: 'int-5', label: 'Heating and A/C operation', checked: false, status: null, notes: '' },
        { id: 'int-6', label: 'Defroster operation', checked: false, status: null, notes: '' },
      ],
    },
  ]);

  const updateItem = (categoryId: string, itemId: string, updates: Partial<ChecklistItem>) => {
    setCategories(prev =>
      prev.map(cat =>
        cat.id === categoryId
          ? {
              ...cat,
              items: cat.items.map(item =>
                item.id === itemId ? { ...item, ...updates } : item
              ),
            }
          : cat
      )
    );
  };

  const totalItems = categories.reduce((sum, cat) => sum + cat.items.length, 0);
  const checkedItems = categories.reduce(
    (sum, cat) => sum + cat.items.filter(item => item.checked).length,
    0
  );
  const passItems = categories.reduce(
    (sum, cat) => sum + cat.items.filter(item => item.status === 'pass').length,
    0
  );
  const failItems = categories.reduce(
    (sum, cat) => sum + cat.items.filter(item => item.status === 'fail').length,
    0
  );
  const attentionItems = categories.reduce(
    (sum, cat) => sum + cat.items.filter(item => item.status === 'attention').length,
    0
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="mx-auto max-w-5xl p-4 sm:p-6 lg:p-8">
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-600">
            <ClipboardCheck className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-slate-900">Vehicle Safety Inspection</h1>
            <p className="text-slate-600">Complete maintenance checklist</p>
          </div>
        </div>

        <InspectionHeader
          vehicleInfo={vehicleInfo}
          setVehicleInfo={setVehicleInfo}
          inspectionDate={inspectionDate}
          setInspectionDate={setInspectionDate}
        />

        <InspectionSummary
          totalItems={totalItems}
          checkedItems={checkedItems}
          passItems={passItems}
          failItems={failItems}
          attentionItems={attentionItems}
        />

        <InspectionChecklist
          categories={categories}
          updateItem={updateItem}
        />
      </div>
    </div>
  );
}
