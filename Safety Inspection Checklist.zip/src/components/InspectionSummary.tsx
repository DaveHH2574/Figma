import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { CheckCircle, XCircle, AlertTriangle, ClipboardList } from 'lucide-react';

interface InspectionSummaryProps {
  totalItems: number;
  checkedItems: number;
  passItems: number;
  failItems: number;
  attentionItems: number;
}

export function InspectionSummary({
  totalItems,
  checkedItems,
  passItems,
  failItems,
  attentionItems,
}: InspectionSummaryProps) {
  const progress = totalItems > 0 ? (checkedItems / totalItems) * 100 : 0;

  return (
    <Card className="mb-6 p-6">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-slate-900">Inspection Progress</h2>
        <span className="text-slate-600">
          {checkedItems} of {totalItems} items checked
        </span>
      </div>
      <Progress value={progress} className="mb-6" />
      
      <div className="grid gap-4 sm:grid-cols-4">
        <div className="flex items-center gap-3 rounded-lg bg-slate-50 p-4">
          <ClipboardList className="h-5 w-5 text-slate-600" />
          <div>
            <div className="text-slate-900">{checkedItems}</div>
            <div className="text-slate-600">Inspected</div>
          </div>
        </div>
        
        <div className="flex items-center gap-3 rounded-lg bg-green-50 p-4">
          <CheckCircle className="h-5 w-5 text-green-600" />
          <div>
            <div className="text-slate-900">{passItems}</div>
            <div className="text-slate-600">Pass</div>
          </div>
        </div>
        
        <div className="flex items-center gap-3 rounded-lg bg-amber-50 p-4">
          <AlertTriangle className="h-5 w-5 text-amber-600" />
          <div>
            <div className="text-slate-900">{attentionItems}</div>
            <div className="text-slate-600">Attention</div>
          </div>
        </div>
        
        <div className="flex items-center gap-3 rounded-lg bg-red-50 p-4">
          <XCircle className="h-5 w-5 text-red-600" />
          <div>
            <div className="text-slate-900">{failItems}</div>
            <div className="text-slate-600">Fail</div>
          </div>
        </div>
      </div>
    </Card>
  );
}
