import { ChecklistCategory, ChecklistItem } from '../App';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from './ui/accordion';
import { Card } from './ui/card';
import { Checkbox } from './ui/checkbox';
import { Textarea } from './ui/textarea';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { CheckCircle, XCircle, AlertTriangle } from 'lucide-react';

interface InspectionChecklistProps {
  categories: ChecklistCategory[];
  updateItem: (categoryId: string, itemId: string, updates: Partial<ChecklistItem>) => void;
}

export function InspectionChecklist({ categories, updateItem }: InspectionChecklistProps) {
  const handleStatusChange = (categoryId: string, itemId: string, status: 'pass' | 'fail' | 'attention') => {
    updateItem(categoryId, itemId, { status, checked: true });
  };

  return (
    <Card className="p-6">
      <h2 className="mb-4 text-slate-900">Inspection Checklist</h2>
      
      <Accordion type="multiple" className="space-y-2">
        {categories.map((category) => {
          const categoryChecked = category.items.filter(item => item.checked).length;
          const categoryTotal = category.items.length;
          const categoryProgress = categoryTotal > 0 ? Math.round((categoryChecked / categoryTotal) * 100) : 0;
          
          return (
            <AccordionItem
              key={category.id}
              value={category.id}
              className="rounded-lg border bg-white px-4"
            >
              <AccordionTrigger className="hover:no-underline">
                <div className="flex w-full items-center justify-between pr-4">
                  <span className="text-slate-900">{category.name}</span>
                  <Badge variant="outline" className="ml-2">
                    {categoryChecked}/{categoryTotal}
                  </Badge>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-4 pt-2">
                  {category.items.map((item) => (
                    <div
                      key={item.id}
                      className="rounded-lg border border-slate-200 bg-slate-50 p-4"
                    >
                      <div className="mb-3 flex items-start gap-3">
                        <Checkbox
                          id={item.id}
                          checked={item.checked}
                          onCheckedChange={(checked) =>
                            updateItem(category.id, item.id, {
                              checked: checked as boolean,
                            })
                          }
                          className="mt-1"
                        />
                        <label
                          htmlFor={item.id}
                          className="flex-1 cursor-pointer text-slate-900"
                        >
                          {item.label}
                        </label>
                      </div>
                      
                      {item.checked && (
                        <div className="ml-7 space-y-3">
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant={item.status === 'pass' ? 'default' : 'outline'}
                              onClick={() => handleStatusChange(category.id, item.id, 'pass')}
                              className={
                                item.status === 'pass'
                                  ? 'bg-green-600 hover:bg-green-700'
                                  : ''
                              }
                            >
                              <CheckCircle className="mr-1 h-4 w-4" />
                              Pass
                            </Button>
                            <Button
                              size="sm"
                              variant={item.status === 'attention' ? 'default' : 'outline'}
                              onClick={() => handleStatusChange(category.id, item.id, 'attention')}
                              className={
                                item.status === 'attention'
                                  ? 'bg-amber-600 hover:bg-amber-700'
                                  : ''
                              }
                            >
                              <AlertTriangle className="mr-1 h-4 w-4" />
                              Attention
                            </Button>
                            <Button
                              size="sm"
                              variant={item.status === 'fail' ? 'default' : 'outline'}
                              onClick={() => handleStatusChange(category.id, item.id, 'fail')}
                              className={
                                item.status === 'fail'
                                  ? 'bg-red-600 hover:bg-red-700'
                                  : ''
                              }
                            >
                              <XCircle className="mr-1 h-4 w-4" />
                              Fail
                            </Button>
                          </div>
                          
                          <Textarea
                            placeholder="Add notes or observations..."
                            value={item.notes}
                            onChange={(e) =>
                              updateItem(category.id, item.id, {
                                notes: e.target.value,
                              })
                            }
                            className="resize-none"
                            rows={2}
                          />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          );
        })}
      </Accordion>
    </Card>
  );
}
