import { Card } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';

interface InspectionHeaderProps {
  vehicleInfo: {
    make: string;
    model: string;
    year: string;
    vin: string;
    mileage: string;
  };
  setVehicleInfo: (info: any) => void;
  inspectionDate: string;
  setInspectionDate: (date: string) => void;
}

export function InspectionHeader({
  vehicleInfo,
  setVehicleInfo,
  inspectionDate,
  setInspectionDate,
}: InspectionHeaderProps) {
  const handleChange = (field: string, value: string) => {
    setVehicleInfo((prev: any) => ({ ...prev, [field]: value }));
  };

  return (
    <Card className="mb-6 p-6">
      <h2 className="mb-4 text-slate-900">Vehicle Information</h2>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <div>
          <Label htmlFor="make">Make</Label>
          <Input
            id="make"
            placeholder="e.g., Toyota"
            value={vehicleInfo.make}
            onChange={(e) => handleChange('make', e.target.value)}
          />
        </div>
        <div>
          <Label htmlFor="model">Model</Label>
          <Input
            id="model"
            placeholder="e.g., Camry"
            value={vehicleInfo.model}
            onChange={(e) => handleChange('model', e.target.value)}
          />
        </div>
        <div>
          <Label htmlFor="year">Year</Label>
          <Input
            id="year"
            placeholder="e.g., 2020"
            value={vehicleInfo.year}
            onChange={(e) => handleChange('year', e.target.value)}
          />
        </div>
        <div>
          <Label htmlFor="vin">VIN</Label>
          <Input
            id="vin"
            placeholder="Vehicle Identification Number"
            value={vehicleInfo.vin}
            onChange={(e) => handleChange('vin', e.target.value)}
          />
        </div>
        <div>
          <Label htmlFor="mileage">Mileage</Label>
          <Input
            id="mileage"
            placeholder="e.g., 45000"
            value={vehicleInfo.mileage}
            onChange={(e) => handleChange('mileage', e.target.value)}
          />
        </div>
        <div>
          <Label htmlFor="date">Inspection Date</Label>
          <Input
            id="date"
            type="date"
            value={inspectionDate}
            onChange={(e) => setInspectionDate(e.target.value)}
          />
        </div>
      </div>
    </Card>
  );
}
